<div class="container">
	<br><br><br>
	<div class="col-lg-12 col-md-12 col-sm-12">
		<div class="panel panel-danger">
			<div class="panel-body">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<strong class="col-lg-12 text-center">No tiene los permisos para acceder a este recurso, comuniquese con su Administrador</strong>
				</div>
			</div>
		</div>

	</div>
</div>
